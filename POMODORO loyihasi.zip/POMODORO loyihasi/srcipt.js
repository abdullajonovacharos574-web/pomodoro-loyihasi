const btn = document.querySelector("button");

let isWork = true;
let timer;

btn.addEventListener("click", function () {

    function startTimer() {

        timer = setTimeout(() => {

            if (isWork) {
                alert("Ish vaqti tugadi! Dam oling.");
                isWork = false;
            } else {
                alert("Dam olish tugadi! Ishni davom ettiring.");
                isWork = true;
            }

            startTimer();

        }, isWork ? 60 * 1000 : 5 * 1000);

    }

    startTimer();

});